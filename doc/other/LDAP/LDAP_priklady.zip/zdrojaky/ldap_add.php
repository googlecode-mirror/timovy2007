<?php
if (isset($firstCallToAdd)) {

   GenerateHTMLHeader("Please fill in fields: (Name and E-mail mandatory)");

   GenerateHTMLForm(0, "myaddrdir_add.php3", "ADD ENTRY");

} else {

   require('myaddrdir_common.php3');
   require('myaddrdir_functions.php3');

   if (!$cn && !$mail && !$locality && !$description && !$telephonenumber) {
      GenerateHTMLHeader("Please fill in fields: (Name and E-mail mandatory)");
      DisplayErrMsg("Atleast the Name and E-mail fields to be entered !!");
      GenerateHTMLForm(0, "myaddrdir_add.php3", "ADD ENTRY");

   } else {

      $entryToAdd["cn"] = $cn;
      $entryToAdd["mail"] = $mail;
      $entryToAdd["locality"] = $locality;
      $entryToAdd["description"] = $description;
      $entryToAdd["telephonenumber"] = $telephonenumber;

      $dnString = "mail=" . $mail . "," . $baseDN;

      $linkIdentifier = ConnectBindServer();
      if ($linkIdentifier) {
         if (ldap_add($linkIdentifier, $dnString, $entryToAdd) == true) {

            GenerateHTMLHeader("The entry was added succesfully");
            ReturnToMain();
         } else {
            DisplayErrMsg("Addition to directory failed !!");
            CloseConnection($linkIdentifier);
            exit;
         }
      } else {
         DisplayErrMsg("Connection to LDAP server failed!");
         exit;
      }
   }
}

?>
