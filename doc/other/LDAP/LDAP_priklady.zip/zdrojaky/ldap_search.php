<?php
require('myaddrdir_common.php3');

$searchFilter = "";


if (!isset($firstCallToSearch)) {
   GenerateHTMLHeader("Search using the following criteria:");
   GenerateHTMLForm(0, "myaddrdir_search.php3", "SEARCH");

} else {

   require('myaddrdir_functions.php3');
   if (!$cn && !$mail && !$locality && !$description && !$telephonenumber) {

   GenerateHTMLHeader("Search using the following criteria:");

   DisplayErrMsg("Atleast one of the fields must be filled !!");
   GenerateHTMLForm(0, "myaddrdir_search.php3", "SEARCH");

   } else {

      $searchCriteria["cn"]              = $cn;
      $searchCriteria["mail"]            = $mail;
      $searchCriteria["locality"]        = $locality;
      $searchCriteria["description"]     = $description;
      $searchCriteria["telephonenumber"] = $telephonenumber;

      $searchFilter = CreateSearchFilter($searchCriteria);

      $linkIdentifier = ConnectBindServer();

      if ($linkIdentifier) {
         $resultEntries = SearchDirectory($linkIdentifier, $searchFilter);

         if ($resultEntries) {
            GenerateHTMLHeader("Search Results:");
            PrintResults($resultEntries);

            ReturnToMain();
         } else {
            ReturnToMain();
         }
      } else {
      DisplayErrMsg("Connection to LDAP server failed !!");
      CloseConnection($linkIdentifier);
      exit;
      }
   }
}

?>
