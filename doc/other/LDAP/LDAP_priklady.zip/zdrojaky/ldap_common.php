<?php
$baseDN = "o=myorg,c=US";

$ldapServer = "localhost";
$ldapServerPort = 9009;
?>
