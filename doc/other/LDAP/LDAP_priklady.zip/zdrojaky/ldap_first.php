<?php

require('myaddrdir_functions.php3');

if (!isset($choice)) {

   GenerateHTMLHeader("Click below to access the Directory");
   GenerateFrontPage();

} else  if (strstr($choice, "ADD")) {
   $firstCallToAdd = 1;

      require('myaddrdir_add.php3');
   } else {
      $firstCallToSearch = 1;
      require('myaddrdir_search.php3');

}
?>
