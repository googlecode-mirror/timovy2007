<?php

require('myaddrdir_common.php3');
require('myaddrdir_functions.php3');

$dnString = "mail=$mail," .$dnString . $baseDN;

$linkIdentifier = ConnectBindServer();
if ($linkIdentifier) {
   if (ldap_delete($linkIdentifier, $dnString) == true) {

      GenerateHTMLHeader("The entry was deleted succesfully");
      ReturnToMain();
   } else {
      DisplayErrMsg("Deletion of entry failed. ");
      CloseConnection($linkIdentifier);
      exit;
   }

   } else {
      DisplayErrMsg("Connection to LDAP server failed !!");
      exit;
   }
?>
